<!DOCTYPE html>
<html lang="fr" class="h-full bg-slate-50">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title','Helpdesk') — Support Technique</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: { sans: ['"Inter"','system-ui','sans-serif'] }
                }
            }
        }
    </script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
   <style>
    .card { background:#fff; border-radius:12px; border:1px solid #e2e8f0; box-shadow:0 1px 3px rgba(0,0,0,.06); }

    .btn { display:inline-flex; align-items:center; justify-content:center; gap:6px; padding:9px 18px; border-radius:8px; font-size:13.5px; font-weight:600; transition:all .18s; cursor:pointer; border-width:1px; border-style:solid; text-decoration:none; white-space:nowrap; }

    .btn-primary   { background:#2563eb; color:#fff; border-color:#1d4ed8; box-shadow:0 2px 4px rgba(37,99,235,.3); }
    .btn-primary:hover { background:#1d4ed8; transform:translateY(-1px); box-shadow:0 4px 8px rgba(37,99,235,.35); }
    .btn-primary:active { transform:translateY(0); }

    .btn-secondary { background:#fff; color:#374151; border-color:#d1d5db; box-shadow:0 1px 3px rgba(0,0,0,.08); }
    .btn-secondary:hover { background:#f9fafb; border-color:#9ca3af; transform:translateY(-1px); box-shadow:0 3px 6px rgba(0,0,0,.1); }
    .btn-secondary:active { transform:translateY(0); }

    .btn-danger    { background:#dc2626; color:#fff; border-color:#b91c1c; box-shadow:0 2px 4px rgba(220,38,38,.3); }
    .btn-danger:hover { background:#b91c1c; transform:translateY(-1px); box-shadow:0 4px 8px rgba(220,38,38,.35); }
    .btn-danger:active { transform:translateY(0); }

    .btn-success   { background:#16a34a; color:#fff; border-color:#15803d; box-shadow:0 2px 4px rgba(22,163,74,.3); }
    .btn-success:hover { background:#15803d; transform:translateY(-1px); }
    .btn-success:active { transform:translateY(0); }

    .btn-warning   { background:#d97706; color:#fff; border-color:#b45309; box-shadow:0 2px 4px rgba(217,119,6,.3); }
    .btn-warning:hover { background:#b45309; transform:translateY(-1px); }
    .btn-warning:active { transform:translateY(0); }

    .btn-sm { padding:6px 12px; font-size:12.5px; border-radius:6px; }
    .btn-lg { padding:11px 24px; font-size:15px; border-radius:10px; }

    .form-input { display:block; width:100%; border-radius:8px; border:1px solid #d1d5db; padding:9px 13px; font-size:14px; box-shadow:0 1px 2px rgba(0,0,0,.05); outline:none; transition:all .18s; background:#fff; color:#111827; }
    .form-input:hover { border-color:#9ca3af; }
    .form-input:focus { border-color:#3b82f6; box-shadow:0 0 0 3px rgba(59,130,246,.18); }
    .form-label { display:block; font-size:13.5px; font-weight:600; color:#374151; margin-bottom:6px; }

    .badge { display:inline-flex; align-items:center; padding:2px 10px; border-radius:999px; font-size:12px; font-weight:600; border-width:1px; border-style:solid; }
    .status-open           { background:#eff6ff; color:#1e40af; border-color:#bfdbfe; }
    .status-in_progress    { background:#fffbeb; color:#92400e; border-color:#fde68a; }
    .status-waiting_client { background:#fff7ed; color:#9a3412; border-color:#fed7aa; }
    .status-resolved       { background:#f0fdf4; color:#166534; border-color:#bbf7d0; }
    .status-closed         { background:#f8fafc; color:#475569; border-color:#e2e8f0; }
    .priority-critical     { background:#fef2f2; color:#991b1b; border-color:#fecaca; }
    .priority-high         { background:#fff7ed; color:#9a3412; border-color:#fed7aa; }
    .priority-medium       { background:#fffbeb; color:#92400e; border-color:#fde68a; }
    .priority-low          { background:#f0fdf4; color:#166534; border-color:#bbf7d0; }

    .nav-link { display:flex; flex-direction:row; align-items:center; gap:10px; padding:8px 12px; border-radius:8px; color:#475569; font-size:14px; font-weight:500; text-decoration:none; transition:all .15s; white-space:nowrap; border:1px solid transparent; }
    .nav-link:hover { background:#f1f5f9; color:#0f172a; border-color:#e2e8f0; }
    .nav-link.active { background:#eff6ff; color:#1d4ed8; border-color:#bfdbfe; font-weight:600; }
    .nav-link svg { flex-shrink:0; width:16px; height:16px; }

    ::-webkit-scrollbar { width:5px; height:5px; }
    ::-webkit-scrollbar-thumb { background:#cbd5e1; border-radius:3px; }
    [x-cloak] { display:none !important; }
</style>
</head>
<body class="h-full font-sans antialiased" x-data="{ sidebarOpen: false }">
<div class="flex h-full">

    {{-- Sidebar desktop --}}
    <aside class="hidden lg:flex lg:w-64 lg:flex-col lg:fixed lg:inset-y-0 border-r border-slate-200 bg-white z-30">
        @include('layouts.sidebar')
    </aside>

    {{-- Sidebar mobile --}}
    <div x-show="sidebarOpen" x-cloak class="fixed inset-0 z-40 lg:hidden">
        <div @click="sidebarOpen=false" class="absolute inset-0 bg-slate-900/50 backdrop-blur-sm"></div>
        <aside class="relative w-72 h-full bg-white border-r border-slate-200 flex flex-col">
            @include('layouts.sidebar')
        </aside>
    </div>

    {{-- Main --}}
    <div class="flex-1 flex flex-col min-h-screen lg:pl-64">

        {{-- Header --}}
        <header class="sticky top-0 z-20 bg-white/90 backdrop-blur border-b border-slate-200">
            <div class="flex items-center justify-between h-16 px-4 sm:px-6">
                <div class="flex items-center gap-3">
                    <button @click="sidebarOpen=true" class="lg:hidden p-2 rounded-lg hover:bg-slate-100 text-slate-500">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"/>
                        </svg>
                    </button>
                    <h1 class="text-base font-semibold text-slate-900">@yield('page-title','Tableau de bord')</h1>
                </div>
                <div class="flex items-center gap-2">
                    <a href="{{ route('tickets.create') }}" class="btn-primary hidden sm:inline-flex">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/>
                        </svg>
                        Nouveau ticket
                    </a>
                    <div x-data="{ open:false }" class="relative">
                        <button @click="open=!open"
                                class="flex items-center gap-2 p-1.5 rounded-lg hover:bg-slate-100 transition-all">
                            <div class="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center text-white text-xs font-bold">
                                {{ strtoupper(substr(Auth::user()->name,0,2)) }}
                            </div>
                            <span class="hidden sm:block text-sm font-medium text-slate-700">{{ Auth::user()->name }}</span>
                            <svg class="w-4 h-4 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/>
                            </svg>
                        </button>
                        <div x-show="open" @click.away="open=false" x-cloak
                             class="absolute right-0 mt-2 w-52 bg-white rounded-xl border border-slate-200 shadow-lg py-1 z-50">
                            <div class="px-4 py-2 border-b border-slate-100">
                                <p class="text-sm font-semibold text-slate-900">{{ Auth::user()->name }}</p>
                                <p class="text-xs text-slate-500">{{ Auth::user()->email }}</p>
                            </div>
                            <a href="{{ route('tickets.index') }}"
                               class="flex items-center gap-2 px-4 py-2 text-sm text-slate-700 hover:bg-slate-50">
                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                                </svg>
                                Mes tickets
                            </a>
                            <form method="POST" action="{{ route('logout') }}">
                                @csrf
                                <button class="flex items-center gap-2 w-full px-4 py-2 text-sm text-red-600 hover:bg-red-50">
                                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/>
                                    </svg>
                                    Se déconnecter
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </header>

        {{-- Flash success --}}
        @if(session('success'))
        <div x-data="{ show:true }" x-show="show" x-init="setTimeout(()=>show=false,5000)"
             class="mx-6 mt-4 flex items-center gap-3 bg-green-50 border border-green-200 rounded-lg px-4 py-3 text-green-800 text-sm">
            <svg class="w-5 h-5 text-green-500 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
            </svg>
            {{ session('success') }}
            <button @click="show=false" class="ml-auto text-green-500 hover:text-green-700">✕</button>
        </div>
        @endif

        {{-- Flash errors --}}
        @if($errors->any())
        <div class="mx-6 mt-4 flex items-start gap-3 bg-red-50 border border-red-200 rounded-lg px-4 py-3 text-red-800 text-sm">
            <svg class="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                <path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clip-rule="evenodd"/>
            </svg>
            <ul class="list-disc ml-3 space-y-0.5">
                @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
        @endif

        <main class="flex-1 p-4 sm:p-6">
            @yield('content')
        </main>

        <footer class="border-t border-slate-200 py-3 px-6 text-center text-xs text-slate-400">
            © {{ date('Y') }} Helpdesk Support Technique
        </footer>
    </div>
</div>
<script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
@stack('scripts')
</body>
</html>